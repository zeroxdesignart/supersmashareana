# Chatbot Arena Clone (Minimal, Local)

This is a minimal local clone of a Chatbot Arena–style interface:

- Multiple bots you can compare side-by-side
- Multiple tools/modes (summarize, explain simply, bullet points, etc.)
- Simple FastAPI backend + vanilla HTML/CSS/JS frontend
- No API keys required to run the demo (bots are toy functions)

## Structure

- `backend/` — FastAPI app exposing:
  - `GET /api/bots`
  - `GET /api/tools`
  - `POST /api/chat`
- `frontend/` — Static site that calls the backend and shows two panels

## Quick Start

1. **Run the backend**

   ```bash
   cd backend
   python -m venv venv
   source venv/bin/activate  # on Windows: venv\Scripts\activate
   pip install -r requirements.txt
   uvicorn main:app --reload
   ```

2. **Run a static server for the frontend**

   ```bash
   cd ../frontend
   python -m http.server 5500
   ```

3. **Open the app**

   Go to: `http://127.0.0.1:5500/index.html`

Now you can type prompts and compare two bots with different tools.

## Extending

- Add more bots in `backend/main.py` inside the `BOTS` dict and in `run_bot`.
- Add more tools in the `TOOLS` dict (each can add its own prefix or behavior).
- Plug in real LLM providers inside `run_bot` by replacing the toy logic.

This gives you a working base you can modify into a full production Arena.
