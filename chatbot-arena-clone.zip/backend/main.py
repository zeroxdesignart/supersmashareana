from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

"""
Simple Chatbot Arena–style backend.

- Multiple "bots" you can compare side-by-side.
- Multiple "tools" (modes) that modify how the message is handled.
- Currently uses toy bots so it runs without any API keys.
- You can later plug in real LLM providers (OpenAI, Anthropic, etc.)
  inside the `run_bot` function.
"""

app = FastAPI(title="Chatbot Arena Clone")

# Allow local frontend (and others) to call this API easily.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    message: str
    bot_id: str
    tool_id: Optional[str] = "none"
    history: Optional[List[ChatMessage]] = None


class ChatResponse(BaseModel):
    reply: str
    bot_id: str
    tool_id: str


# --- Bot + Tool configuration ------------------------------------------------

BOTS: Dict[str, Dict[str, Any]] = {
    "echo": {
        "name": "Echo Bot",
        "description": "Repeats back what you say with a tiny comment.",
    },
    "reverse": {
        "name": "Reverse Bot",
        "description": "Answers by reversing your message.",
    },
    "keyword": {
        "name": "Keyword Bot",
        "description": "Picks out what it thinks are the main keywords.",
    },
}

TOOLS: Dict[str, Dict[str, Any]] = {
    "none": {
        "name": "Plain Chat",
        "description": "Send the message as-is.",
        "prefix": "",
    },
    "summary": {
        "name": "Summarize",
        "description": "Summarize the message into 1–2 sentences.",
        "prefix": "Summarize this in 1–2 sentences: ",
    },
    "explain_simple": {
        "name": "Explain Simply",
        "description": "Explain the message like to a 9th grader.",
        "prefix": "Explain this in simple terms: ",
    },
    "bullet_points": {
        "name": "Bullet Points",
        "description": "Turn the message into bullet points.",
        "prefix": "Turn this into clear bullet points: ",
    },
}


# --- Toy bot implementations --------------------------------------------------

def run_bot(bot_id: str, text: str) -> str:
    """
    For now, these are simple Python functions so the app works out-of-the-box.

    To plug in real LLMs, replace this logic with calls to your providers,
    e.g. OpenAI, Anthropic, local models, etc.
    """
    if bot_id == "echo":
        return f"You said: {text}\n\n(I'm Echo Bot, just mirroring you.)"

    if bot_id == "reverse":
        return f"Reversed: {text[::-1]}"

    if bot_id == "keyword":
        # Naive keyword extraction: unique words sorted by frequency.
        import re
        words = re.findall(r"\w+", text.lower())
        from collections import Counter

        counts = Counter(words)
        # Take the top 10 words
        top = [w for w, c in counts.most_common(10)]
        return "Top keywords I see:\n- " + "\n- ".join(top)

    # Fallback
    return f"[{bot_id}] (demo bot): {text}"


# --- API routes ---------------------------------------------------------------

@app.get("/api/bots")
def list_bots():
    return [
        {"id": bot_id, "name": cfg["name"], "description": cfg["description"]}
        for bot_id, cfg in BOTS.items()
    ]


@app.get("/api/tools")
def list_tools():
    return [
        {
            "id": tool_id,
            "name": cfg["name"],
            "description": cfg["description"],
        }
        for tool_id, cfg in TOOLS.items()
    ]


@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    if req.bot_id not in BOTS:
        raise HTTPException(status_code=400, detail="Unknown bot_id")
    if req.tool_id not in TOOLS:
        raise HTTPException(status_code=400, detail="Unknown tool_id")

    tool = TOOLS[req.tool_id]
    prefix = tool.get("prefix", "")
    full_text = prefix + req.message

    reply = run_bot(req.bot_id, full_text)

    return ChatResponse(
        reply=reply,
        bot_id=req.bot_id,
        tool_id=req.tool_id,
    )


# Helpful for local dev: `python main.py`
if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
